import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { EstimateFormComponent } from './components/estimate-form/estimate-form.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, EstimateFormComponent],
  template: `
    <main>
      <app-estimate-form></app-estimate-form>
      <router-outlet />
    </main>
  `,
  styles: [`
    main {
      display: block;
      width: 100%;
      min-height: 100vh;
      background: #F5F6FE;
      padding: 20px;
    }
  `]
})
export class AppComponent {
  title = 'angular';
}