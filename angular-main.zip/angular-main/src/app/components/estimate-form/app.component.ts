import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-estimate-form',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './estimate-form.component.html',
  styleUrls: ['./estimate-form.component.css']
})
export class EstimateFormComponent {
  formData = {
    name: '',
    phoneNumber: '',
    email: '',
    date: ''
  };

  showToast = false;
  toastMessage = '';
  isError = false;

  onSubmit(): void {
    if (!this.validateName(this.formData.name)) {
      this.showMessage('Please enter a valid name (at least 2 characters).', true);
      return;
    }
    
    if (!this.validatePhone(this.formData.phoneNumber)) {
      this.showMessage('Please enter a valid phone number (at least 7 digits).', true);
      return;
    }
    
    if (!this.validateEmail(this.formData.email)) {
      this.showMessage('Please enter a valid email address (example@domain.com).', true);
      return;
    }
    
    if (!this.validateDate(this.formData.date)) {
      this.showMessage('Please enter a valid date in dd - mm - yyyy format (e.g., 15 - 08 - 2025).', true);
      return;
    }

    console.log('Form submitted:', this.formData);
    this.showMessage('✅ Estimate request submitted! Our team will reach out shortly.', false);
  }

  validateName(name: string): boolean {
    if (name && name.trim().length >= 2) {
      return true;
    }
    return false;
  }

  validatePhone(phone: string): boolean {
    const digits = phone.replace(/[\s\-\(\)]/g, '');
    if (digits.length >= 7 && /^[\d\+\(\)\s\-]+$/.test(phone)) {
      return true;
    }
    return false;
  }

  validateEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@([^\s@.,]+\.)+[^\s@.,]{2,}$/;
    if (email && emailRegex.test(email.trim())) {
      return true;
    }
    return false;
  }

  validateDate(dateStr: string): boolean {
    if (!dateStr || dateStr.trim() === '') {
      return false;
    }
    
    const cleaned = dateStr.trim();
    const match = cleaned.match(/^(\d{1,2})[\s\-\.\/]+(\d{1,2})[\s\-\.\/]+(\d{4})$/);
    
    if (match) {
      const day = parseInt(match[1], 10);
      const month = parseInt(match[2], 10);
      const year = parseInt(match[3], 10);
      if (day >= 1 && day <= 31 && month >= 1 && month <= 12 && year >= 1900 && year <= 2100) {
        return true;
      }
    }
    return false;
  }

  onPhoneInput(event: Event): void {
    const input = event.target as HTMLInputElement;
    let value = input.value.replace(/\D/g, '');
    if (value.length > 10) value = value.slice(0, 10);
    
    let formatted = '';
    if (value.length >= 7) {
      formatted = `(${value.slice(0,3)}) ${value.slice(3,6)} - ${value.slice(6,10)}`;
    } else if (value.length >= 4) {
      formatted = `(${value.slice(0,3)}) ${value.slice(3)}`;
    } else if (value.length > 0) {
      formatted = value;
    }
    
    this.formData.phoneNumber = formatted;
  }

  onDateInput(event: Event): void {
    const input = event.target as HTMLInputElement;
    let raw = input.value.replace(/\D/g, '');
    if (raw.length > 8) raw = raw.slice(0, 8);
    
    let formatted = '';
    if (raw.length >= 2) {
      const dayPart = raw.slice(0, 2);
      formatted = dayPart;
      if (raw.length >= 4) {
        const monthPart = raw.slice(2, 4);
        formatted = `${dayPart} - ${monthPart}`;
        if (raw.length >= 8) {
          const yearPart = raw.slice(4, 8);
          formatted = `${dayPart} - ${monthPart} - ${yearPart}`;
        } else if (raw.length > 4) {
          const yearPart = raw.slice(4);
          formatted = `${dayPart} - ${monthPart} - ${yearPart}`;
        }
      } else if (raw.length > 2) {
        const monthPart = raw.slice(2);
        formatted = `${dayPart} - ${monthPart}`;
      }
    } else {
      formatted = raw;
    }
    
    this.formData.date = formatted;
  }

  showMessage(message: string, error: boolean = false): void {
    this.toastMessage = message;
    this.isError = error;
    this.showToast = true;
    
    setTimeout(() => {
      this.showToast = false;
    }, 2800);
  }

  resetForm(): void {
    this.formData = {
      name: '',
      phoneNumber: '',
      email: '',
      date: ''
    };
  }
}